All that has to be done is to put images in the corresponding folders in PHOTOS,
then run main.

1000 image triplets takes around an hour on a 6 core AMD FX 6300 @4.0gz

Make sure that parallel toolbox is installed to utilize all of your cores.