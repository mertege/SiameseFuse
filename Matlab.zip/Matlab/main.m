clear;
%clc;

fused = dir('PHOTOS/FUSED');
rgb = dir('PHOTOS/RGB');
inf = dir('PHOTOS/INFRARED');
fused = {fused.name};
rgb = {rgb.name};
inf = {inf.name};
fused = natsortfiles(fused);
inf = natsortfiles(inf);
rgb = natsortfiles(rgb);

sampleCount = 0;

for i = 1:length(rgb)    
    if (string(fused(i)) == "." || string(fused(i)) == "..")
        continue;
    end
    sampleCount = sampleCount + 1;
    
    strcat("PHOTOS/FUSED/",string(fused(i)));
    strcat("PHOTOS/RGB/",string(rgb(i)));
    strcat("PHOTOS/INFRARED/",string(inf(i)));

    fileName_source_ir  = strcat("PHOTOS/INFRARED/",string(inf(i)));% ["infrared image name"];
    fileName_source_vis = strcat("PHOTOS/RGB/",string(rgb(i)));% ["visible image name"];
    fileName_fused      = strcat("PHOTOS/FUSED/",string(fused(i)));% ["fused image name"];
    disp("--------------------");
    disp(fileName_source_ir);
    disp(fileName_source_vis);
    disp(fileName_fused);    
    
end

disp("Check above for allignment");

EN_ARRAY= zeros(length(fused) ,1);
MI_ARRAY= zeros(length(fused) ,1);
Qabf_ARRAY= zeros(length(fused) ,1);
FMI_pixel_ARRAY= zeros(length(fused) ,1);
FMI_dct_ARRAY= zeros(length(fused) ,1);
FMI_w_ARRAY= zeros(length(fused) ,1);
Nabf_ARRAY= zeros(length(fused) ,1);
SCD_ARRAY= zeros(length(fused) ,1);
SSIM_ARRAY= zeros(length(fused) ,1); 
MS_SSIM_ARRAY= zeros(length(fused) ,1);

parfor i = 1:length(rgb) 
    if (string(fused(i)) == "." || string(fused(i)) == "..")
        continue;
    end
        
    % Li H, Wu X J. DenseFuse: A Fusion Approach to Infrared and Visible Images[J]. arXiv preprint arXiv:1804.08361, 2018. 
    % https://arxiv.org/abs/1804.08361
    % ^ Their source code compilation was edited for automation
    
    fileName_source_ir  = strcat("PHOTOS/INFRARED/",string(inf(i)));% ["infrared image name"];
    fileName_source_vis = strcat("PHOTOS/RGB/",string(rgb(i)));% ["visible image name"];
    fileName_fused      = strcat("PHOTOS/FUSED/",string(fused(i)));% ["fused image name"];
       
    source_image1 = imread(fileName_source_ir);    
    source_image2 = imread(fileName_source_vis);
    fused_image   = imread(fileName_fused);
    
    % resize 256 256 for compatability 
    source_image1 = imresize(source_image1,[256 256]);
    source_image2 = imresize(source_image2,[256 256]);
    fused_image   = imresize(fused_image, [256 256]);
    
    [x,y,c] = size(source_image1);
    if (c > 1)
        source_image1 = rgb2gray(source_image1);
    end
    [x,y,c] = size(source_image2);
    if (c > 1)
        source_image2 = rgb2gray(source_image2);
    end
    [x,y,c] = size(fused_image);
    if (c > 1)
        fused_image = rgb2gray(fused_image);
    end

       
    disp("---------PROGRESS---------");    
    %--------------------------- 
    disp(["image",int2str(i - 2), "out of ", int2str(length(rgb) - 2)])%disp("Start");
    %%disp('---------------------------Analysis---------------------------');
    [EN,MI,Qabf,FMI_pixel,FMI_dct,FMI_w,Nabf,SCD,SSIM, MS_SSIM] = analysis_Reference(fused_image,source_image1,source_image2)
    %disp('Done');
    disp(["image",int2str(i - 2), "out of ", int2str(length(rgb) - 2)])%disp("Start");
    disp("---------------------------");
    
    EN_ARRAY(i) = EN;
    MI_ARRAY(i) = MI;
    Qabf_ARRAY(i) = Qabf;
    FMI_pixel_ARRAY(i) = FMI_pixel;
    FMI_dct_ARRAY(i) = FMI_dct;
    FMI_w_ARRAY(i) = FMI_w;
    Nabf_ARRAY(i) = Nabf;
    SCD_ARRAY(i) = SCD;
    SSIM_ARRAY(i) = SSIM; 
    MS_SSIM_ARRAY(i) = MS_SSIM;
    
end


disp("   ");
disp("   ");
disp("    DONE");


EN_AVERAGE = sum(EN_ARRAY) / sampleCount
MI_AVERAGE = sum(MI_ARRAY) / sampleCount
Qabf_AVERAGE = sum(Qabf_ARRAY) / sampleCount
FMI_pixel_AVERAGE = sum(FMI_pixel_ARRAY) / sampleCount
FMI_dct_AVERAGE = sum(FMI_dct_ARRAY) / sampleCount
FMI_w_AVERAGE = sum(FMI_w_ARRAY) / sampleCount
Nabf_AVERAGE = sum(Nabf_ARRAY) / sampleCount 
SCD_AVERAGE  = sum(SCD_ARRAY) / sampleCount
SSIM_AVERAGE = sum(SSIM_ARRAY) / sampleCount
MS_SSIM_AVERAGE = sum(MS_SSIM_ARRAY) / sampleCount


